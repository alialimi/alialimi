/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install python3
sudo pip3 install pyinstaller==4.2 cryptography==36.0.1 colorama